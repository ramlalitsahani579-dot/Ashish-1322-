# Domi App — Android App Kaise Banayein (Step-by-Step)

Ye poora process aapke apne computer par karna hoga, kyunki isme internet aur
Android Studio (Google ka tool) chahiye hote hain — ye cheezein AI chat ke
andar nahi ho sakti.

Total time: pehli baar karne mein ~30-45 minute lagenge (zyada tar
downloading/setup mein).

---

## Cheezein jo chahiye honge (sab FREE hain)

1. **Node.js** — https://nodejs.org (LTS version download karein, "Next Next
   Next" karke install ho jaata hai)
2. **Android Studio** — https://developer.android.com/studio (bada download
   hai, ~1 GB — WiFi par karein)
3. Ye pura **domi-project** folder (jo aapne abhi download kiya)

---

## Step 1: Node.js aur Android Studio install karein

Dono ko normal software ki tarah install karein (Next → Next → Finish).
Android Studio pehli baar kholne par khud SDK download karega — usko hone dein
(internet chahiye).

## Step 2: Terminal/Command Prompt kholein is folder mein

Windows par: is folder ke andar jaake address bar mein `cmd` type karke Enter
dabayein.
Mac par: folder par right-click → "New Terminal at Folder".

## Step 3: Ye commands ek-ek karke chalayein

```
npm install
npx cap add android
npx cap sync
```

Pehli command sab zaroori packages download karegi. Doosri command Android
project banayegi. Teesri command aapki `www/index.html` file ko Android
project ke andar copy karegi.

## Step 4: Android Studio mein kholein

```
npx cap open android
```

Ye Android Studio khol dega aapke Domi project ke saath. Pehli baar khulne
mein thoda time lagega (Gradle sync hota hai) — bas wait karein.

## Step 5: Apne phone par test karein

- Apne Android phone mein **Developer Options** aur **USB Debugging** on
  karein (Settings → About Phone → Build Number ko 7 baar tap karein, phir
  Developer Options mein USB Debugging on karein)
- Phone ko USB se computer se connect karein
- Android Studio mein upar **Run (▶) button** dabayein
- App aapke phone par install ho jaayegi aur khul jaayegi!

## Step 6: Play Store ke liye taiyaar karna (jab poori tarah ready ho)

1. Android Studio mein: **Build → Generate Signed Bundle / APK**
2. **Android App Bundle (.aab)** choose karein (Play Store isi format mein
   chahta hai)
3. Ek naya "keystore" banayein (ye aapki app ki permanent digital pehchaan
   hai — **isko safe rakhein, kabhi mat khoyein**, warna future updates nahi
   bhej paayenge)
4. https://play.google.com/console par jaake **Developer account banayein**
   (**one-time $25 fee** Google leta hai)
5. Apni app upload karein, screenshots/description daalein, aur **staged
   rollout** (5%, 20%... jitni chaho utni audience) choose karke publish
   karein

---

## Baad mein kuch change/add karna ho to?

Bas `www/index.html` file ko edit karein (ya mujhse naya version banwa lein),
phir dobara ye chalayein:

```
npx cap sync
```

Aur Android Studio mein phir se Run dabayein. Chhote content/design changes
ke liye Play Store par dobara submit karne ki zaroorat nahi padegi agar aap
app ko hosted content se load karwate hain — abhi ke liye ye seedha bundled
hai, jo simpler hai shuruaat ke liye.

---

## Koi problem aaye to

Agar koi command error de ya Android Studio mein kuch samajh na aaye, uska
exact error message copy karke mujhe bhej dena — main uska solution bata
dunga.
